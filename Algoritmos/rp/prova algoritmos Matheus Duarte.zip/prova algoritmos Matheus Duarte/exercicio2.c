#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
    setlocale(LC_ALL, "portuguese");
    srand(time(NULL));
    int vetor[8];
    int maior, menor;

    for (int i = 0; i < 8; i++) {
        vetor[i] = rand() % 5;
    }


    for (int i = 0; i < 8; i++) {
        printf("%d� Cota��o do dia: \n%d\n",i+1, vetor[i]);
    }

    menor = vetor[0];

    for (int i = 0; i < 8; i++) {
        if (vetor[i] < menor) {
            menor = vetor[i];
        }
        if (vetor[i] > maior) {
            maior = vetor[i];
        }
    }

    printf("menor cota��o do dia = %d\n", menor);
    printf("maior cota��o do dia = %d\n", maior);

    return 0;
}
