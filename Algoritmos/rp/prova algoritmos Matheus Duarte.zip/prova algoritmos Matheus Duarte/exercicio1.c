#include <stdio.h>
#include <locale.h>

struct Aluno {
    char nome[50];
    char endereco[100];
    int numeroMatricula;
};

typedef struct Aluno aluno;

void lerDados(aluno alunos[10]) {
    setlocale(LC_ALL, "portuguese");
    for (int i = 0; i < 10; i++) {
        printf("Digite o nome do aluno %d: \n", i + 1);
        scanf("%s", alunos[i].nome);

        printf("Digite o endere�o do aluno %d: \n", i + 1);
        scanf("%s", alunos[i].endereco);

        printf("Digite o n�mero de matr�cula do aluno %d: \n", i + 1);
        scanf("%d", &alunos[i].numeroMatricula);
    }
}

void imprimirAlunos(aluno alunos[10]) {
    for (int i = 0; i < 10; i++) {
        printf("Aluno %d:\n", i + 1);
        printf("Nome: %s\n", alunos[i].nome);
        printf("Endere�o: %s\n", alunos[i].endereco);
        printf("N�mero de Matr�cula: %d\n", alunos[i].numeroMatricula);
    }
}

int main(void) {
    aluno alunos[10];
    lerDados(alunos);
    imprimirAlunos(alunos);
}
